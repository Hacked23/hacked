# F-Tools

![Version](https://img.shields.io/badge/Version-2.0-green) ![Lang](https://img.shields.io/badge/Language-Bash-lime)

![](https://raw.githubusercontent.com/FajarTheGGman/F-Tools/master/.img/banner.png)
![](https://raw.githubusercontent.com/FajarTheGGman/F-Tools/master/.img/content.png)

# Tutorial Instalation

# Termux
<pre>
1.pkg install git
2.git clone https://github.com/FajarTheGGman/F-Tools
3.cd F-Tools
4.bash F-Tools.sh
</pre>

# Linux
<pre>
1.apt-get install git
2.git clone https://github.com/FajarTheGGman/F-Tools
3.cd F-Tools
4.sudo bash F-Tools.sh
</pre>


Whats New ?

- Add new tools
- New Interface 
- Simply 
